public class BasicsTest {
    
    public static void main(String[] args) {
        
    }
}
