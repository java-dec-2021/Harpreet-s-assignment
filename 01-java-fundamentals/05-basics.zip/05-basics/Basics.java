import java.util.Arrays;

ArrayList<Integer> myArray = new ArrayList<Integer>();
