public class ProjectTest {
    public static void main(String[] args) {
        Project project1 = new Project();
        System.out.println(project1.getName());
        System.out.println(project1.getDescription());
        System.out.println(project1.elevatorPitch());
    }
}
